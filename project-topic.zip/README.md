# Project

Develop a preparedness plan for disasters - specifically pandemics